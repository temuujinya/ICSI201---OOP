	#include<iostream>
	using namespace std;
	int main() {
	    char * p1;
	    int * p2;
	    double * p3;
	    cout << sizeof(p1) << sizeof(p2) << sizeof(p3);
	}
